@echo off

rem _REIMAGINED BETA LAUNCHER
rem _Constants

setlocal EnableDelayedExpansion
set "debug=0"
set "log_file=%~dp0launcher_log.txt"
set "launcher=%~dp0"
if "%launcher:~-1%"=="\" set "launcher=%launcher:~0,-1%"
set "settings=%launcher%\settings.txt"
set "max_backups=5"

rem _Query for D2R install location
for /f "usebackq tokens=3*" %%A in (`reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Diablo II Resurrected" /v InstallLocation 2^>nul`) do set "appdir=%%A %%B"

rem _Query D2RMM install location
for /f "usebackq tokens=*" %%O in (`reg query "HKEY_CURRENT_USER\SOFTWARE\Classes\nxm\shell\open\command" /ve 2^>nul`) do (
    set "RAW=%%O"
)
:: Remove the registry header (everything before the actual path)
set "D2RMMappdir=!RAW:*REG_SZ=!"
:: Clean up leading spaces, quotes, and the trailing %1
:: Remove quotes
set "D2RMMappdir=!D2RMMappdir:"=!"
:: Remove leading spaces
for /f "tokens=* delims= " %%P in ("!D2RMMappdir!") do set "D2RMMappdir=%%P"
:: Remove the trailing %1
set "D2RMMappdir=!D2RMMappdir: %%1=!"
:: Remove the executable name to leave only the folder path
set "D2RMMappdir=!D2RMMappdir:D2RMM.exe=!"
:: --- NEW: Remove trailing backslash if it exists ---
if "!D2RMMappdir:~-1!"=="\" set "D2RMMappdir=!D2RMMappdir:~0,-1!"

rem _for identifying the Reimagined MOD Version Number in Main Menu from the file modinfo.json
SET "modjsonPath=%appdir%\mods\Reimagined\Reimagined.mpq\modinfo.json"

IF EXIST "%modjsonPath%" (
    (FOR /L %%Z IN (1,1,3) DO SET /P VersionCheck=) < "%modjsonPath%"
) ELSE (
    SET VersionCheck=**NOT INSTALLED!**
)

rem _for Identifying the Diablo II Resurrected D2R.exe full path to display in the Main Menu and used with the d2rexe product version lookup
SET "EXE_PATH=%appdir%\D2R.exe"
IF EXIST "%EXE_PATH%" (
SET "GamePathCheck=%EXE_PATH%"
) ELSE (
    SET "GamePathCheck=**NOT INSTALLED!**"
)
FOR /F "USEBACKQ" %%R IN (`powershell -NoLogo -NoProfile -Command ^(Get-Item "'%EXE_PATH%'"^).VersionInfo.ProductVersion`) DO (
    SET "D2REXEVERSION=%%R"
)

rem _for adding colored text to the Main Menu
for /f "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do (
    set "ESC=%%b"
)

REM Define some color text variables for convenience (optional)
set "Red=%ESC%[91m"
set "Green=%ESC%[92m"
set "Yellow=%ESC%[93m"
set "Blue=%ESC%[94m"
set "Purple=%ESC%[95m"
set "Cyan=%ESC%[96m"
set "White=%ESC%[97m"
set "Reset=%ESC%[0m"

:display
REM Display the captured line
ECHO %line%

rem _Initialization
call :LogMessage "Launcher started"
call :CreateCheckSettings
call :VerifyD2RInstall
call :VerifyReimaginedFolder
call :FindOrCreateSaveDir
call :FindOrCreateBackupDir

rem _Main Menu

:MainMenu
cls
echo.
color 0E
echo  %Blue%----- REIMAGINED BETA LAUNCHER FOR DIABLO 2 BATTLE.NET VERSION v8.6 -----
echo.
echo %Yellow%This Beta Launcher is for only Reimagined 3.x releases.
echo If you are using the Steam version of Diablo 2, then use the %Cyan%blue text%Yellow% Beta Launcher
echo.
echo All Mod Tweaks are removed after Install/Update - so you must redo them
echo.
echo.
echo  [1] Play Reimagined
echo.
echo %Blue%Mod Options:%Yellow%
echo  [2] Install / Update - the Reimagined Mod
echo  [3] Mod Tweaks (2 Skill, Golden Portals, Forced TZones, Casc Fastloading)
echo  [4] %Purple%D2RMM USERS ONLY - Install / Update %Red%(Copies MOD to D2RMM folder - Afterwards you must Click Install inside D2RMM)%Yellow%
echo  [5] %Purple%D2RMM USERS ONLY - Mod Tweaks %Red%(After you clicked Install inside D2RMM return here)%Yellow%
echo  [6] Backup Save Files
echo.
echo %Blue%Community Links:%Yellow%
echo  [7] Visit Reimagined Website
echo  [8] Visit Reimagined Wiki
echo  [9] Visit Reimagined Nexus Page (Official Reimagined Launcher here too)
echo  [10] Visit Reimagined Discord Server
echo						%Red%REIMAGINED CURRENTLY INSTALLED:%Green% %VersionCheck%
echo.
echo  %Yellow%[X] Exit Launcher			%Blue%Your Diablo II Resurrected Game Information:
echo						%Red%Full Game Path:%White% %GamePathCheck%
echo						%Red%D2R.exe Product Version:%White% %D2REXEVERSION%
call :GetInput "What would you like to do:%Yellow% " "1 2 3 4 5 6 7 8 9 10 X" && set "menu_choice=!result!"
if "%menu_choice%"=="1" goto PlayReimagined
if "%menu_choice%"=="2" goto InstallUpdate
if "%menu_choice%"=="3" goto ConfigurationMenu
if "%menu_choice%"=="4" goto D2RMMInstallUpdate
if "%menu_choice%"=="5" goto D2RMMConfigurationMenu
if "%menu_choice%"=="6" goto BackupFiles
if "%menu_choice%"=="7" call :OpenLink "https://www.d2R-reimagined.com" & goto MainMenu
if "%menu_choice%"=="8" call :OpenLink "https://wiki.d2R-reimagined.com" & goto MainMenu
if "%menu_choice%"=="9" call :OpenLink "https://www.nexusmods.com/diablo2resurrected/mods/503" & goto MainMenu
if "%menu_choice%"=="10" call :OpenLink "https://discord.gg/5bbjneJCrr" & goto MainMenu
if /i "%menu_choice%"=="X" call :LogMessage "Launcher exited" & exit
call :ErrorHandler "Invalid choice. Please try again." MainMenu

rem _Play Reimagined

:PlayReimagined
call :LogMessage "Attempting to play Reimagined"
call :Check7zFiles
call :VerifyReimaginedFolder
call :CreateBackup
if "%mod_checked%"=="0" (
  start "" "%appdir%\D2R.exe" -mod Reimagined -txt
  call :LogMessage "Game launched"
  exit
  ) else (
  call :ErrorHandler "Reimagined mod folder not found or empty." InstallUpdate
)

rem _Install/Update

:InstallUpdate
call :LogMessage "Checking for mod installation"
call :Check7zFiles
cls
echo.
echo  %Blue%----- INSTALL / UPDATE -----%Yellow%
echo.
echo Saved games are always safe when Installing or Updating the mod.
echo.
echo Mod Zip file detected: %truncated_install_file_name%
echo.
call :GetInput "Would you like to install this version now? (Y/N): " "Y N" && set "install_choice=!result!"
if /i "%install_choice%"=="Y" (
  if exist "%appdir%\mods\Reimagined" (
    call :LogMessage "Removing old mod files"
    rmdir /s /q "%appdir%\mods\Reimagined"
  )
  call :InstallReimagined
  ) else if /i "%install_choice%"=="N" (
  call :ErrorHandler "Installation skipped." MainMenu
  ) else (
  call :ErrorHandler "Invalid choice. Please enter Y or N." InstallUpdate
)

:InstallReimagined
if not defined install_file call :ErrorHandler "Error: No installation file found." Check7zFiles
call :LogMessage "Installing %truncated_install_file_name%"
echo Installing %truncated_install_file_name%...
tar -xf "%install_file%" -C "%appdir%" >nul 2>&1
if errorlevel 1 call :ErrorHandler "Error: Failed to extract the zip file." InstallUpdate
call :LogMessage "Installation completed"
echo Installation completed successfully!
timeout /t 3 >nul
echo Restarting the launcher...
pause
start "" "%~f0"
exit

rem _Configuration Menu

:ConfigurationMenu
call :LogMessage "Entering configuration menu"
:ConfigurationMenuLoop
cls
echo.
echo  %Blue%----- MOD TWEAKS -----%Yellow%
echo.
echo To reset these options, re-run Install / Update
echo.
echo %Blue%Modification Options:%Yellow%
echo  [1] Remove Aura Sounds (NEW!)
echo  [2] Force Terror Zones (Every Act)
echo  [3] Increase Level Up Stats (2 Skill/8 Attributes)
echo  [4] Golden Town Portals (Replaces the default blue portals)
echo  [5] Letterbox Removal (Removes dim lighting on far edges of screen)
echo  [6] HDR Tooltip Fix
echo  [7] Remove Splash Charm Graphic Effect
echo  [8] CASC Fastloading + Mod Reinstall (Takes your PC 5-15 minutes + resets 1-6 above)
echo.
echo  [X] Back to Main Menu
echo.
call :GetInput "What would you like to do: " "1 2 3 4 5 6 7 8 X" && set "advoption_choice=!result!"
set "action="
if "%advoption_choice%"=="1" set "action=RemoveAuraSounds"
if "%advoption_choice%"=="2" set "action=ForceTerrorZones"
if "%advoption_choice%"=="3" set "action=IncreaseLevelStats"
if "%advoption_choice%"=="4" set "action=GoldenTownPortals"
if "%advoption_choice%"=="5" set "action=LetterboxRemoval"
if "%advoption_choice%"=="6" set "action=HDRTooltipFix"
if "%advoption_choice%"=="7" set "action=SplashCharmGraphic"
if "%advoption_choice%"=="8" set "action=CASCFastloading"
if /i "%advoption_choice%"=="X" goto MainMenu
if defined action goto !action!
call :ErrorHandler "Invalid choice. Please try again." ConfigurationMenuLoop

rem _Configuration Options

:RemoveAuraSounds
call :ApplyMod "Remove Aura Sounds" "removed_aura_sounds" "%launcher%\utils\mods\Remove Aura Sounds\mods" "%appdir%\mods\"

:ForceTerrorZones
call :ApplyMod "Force Terror Zones" "forced_terror_zones" "%launcher%\utils\mods\Force Terror Zones\mods" "%appdir%\mods\"

:SplashCharmGraphic
call :ApplyMod "Splash Charm Graphic Removal" "splash_charm_graphic_removed" "%launcher%\utils\mods\Splash Charm Graphic\mods" "%appdir%\mods\"

:IncreaseLevelStats
call :ApplyMod "Increase Level Stats" "increased_level_stats" "%launcher%\utils\mods\Increase Level Stats\mods" "%appdir%\mods\"

:GoldenTownPortals
call :ApplyMod "Golden Town Portals" "golden_town_portals" "%launcher%\utils\mods\Golden Town Portals\mods" "%appdir%\mods\"

:LetterboxRemoval
call :ApplyMod "Letterbox Removal" "letterbox_removal" "%launcher%\utils\mods\Letterbox\mods" "%appdir%\mods\"

:HDRTooltipFix
call :ApplyMod "HDR Tooltip Fix" "hdr_tooltip_fix" "%launcher%\utils\mods\HDR Tooltip Fix\mods" "%appdir%\mods\"

:CASCFastloading
call :LogMessage "Configuring CASC Fastloading"
cls
echo.
echo  ----- CASC FASTLOADING -----
echo.
echo CASC Fastloading will use an additional 42GB of free space.
for /f "tokens=*" %%A in ('powershell -Command "[math]::Floor((Get-PSDrive -Name %appdir:~0,1%).Free / 1GB)"') do set "free_space_gb=%%A"
if %free_space_gb% lss 42 call :ErrorHandler "Not enough disk space (42GB required)." ConfigurationMenuLoop
echo Currently your free space: %free_space_gb% GB
echo.
echo This only affects the Reimagined Mod.
echo.
echo Anytime you reinstall the mod, come back and redo this for the quick loading speed.
echo Make sure your Nexus zip file is inside the Beta Launcher's folder first,
echo as this process needs to reinstall Reimagined at the very end.
echo.
echo BENEFITS
echo Diablo 2 won't have to uncompress game files anymore while playing.
echo Extremly fast act load times + slightly lowers the D2 system requirements.
echo.
echo.
echo **WARNING: THIS WILL TAKE BETWEEN 5-15 MINUTES**
echo.
call :GetInput "Proceed? (Y/N): " "Y N" && set "casc_choice=!result!"
if /i "%casc_choice%"=="Y" (
  call :LogMessage "Starting CASC Fastloading"
  echo.
  echo Currently extracting over 150,000 game files + 12,000 folders. 
  echo These extra files are put into \mods\Reimagined\ affecting offline mod use only.
  echo Your Mod Tweaks such as 2SKILL FORCED TERRORZONES all reset after this, so you must reapply them.
  echo.
  echo WHAT IS CASC FASTLOADING?
  echo Before running this, installed game files are compressed, requiring your PC to work hard to unpack while playing.
  echo After running this, the game is completely uncompressed, allowing your PC to work less while playing.
  echo.
  echo BENEFITS: Faster game loading, faster act switching + reduced microstutters, better fps.
  echo DRAWBACKS: Uses an extra 42GB + this process takes time and must be repeated after every mod reinstall.
  echo 1st time entering each act loadtimes might take longer, but afterwards loadtime will be fast even after you quit.
  echo.
  echo.
  echo This page will refresh when it's completed below.
  echo DO NOT CLOSE THIS WINDOW.  IT SHOULD TAKE 5-15 MINUTES.
  md "%appdir%\casctemp" >nul 2>&1
  rem _Missing CASC Console or utils folder
  if not exist "%launcher%\utils\Casc\CASCConsole.exe" call :ErrorHandler "Error: CASCConsole.exe not found." ConfigurationMenuLoop
  rem _Extraction Start
  "%launcher%\utils\Casc\CASCConsole.exe" -l None -d "%appdir%\casctemp" -s "%appdir%" -m Pattern -e data/data/*.* -p osi >nul 2>&1
  rem _Error during the extraction process
  if errorlevel 1 call :ErrorHandler "Failed to extract game files." ConfigurationMenuLoop
  rem _Move everything to D2R install and delete the temp directory
  if exist "%appdir%\casctemp\data\data" (
    rmdir /s /q "%appdir%\mods\Reimagined\Reimagined.mpq\data" >nul 2>&1
    move /y "%appdir%\casctemp\data\data" "%appdir%\mods\Reimagined\Reimagined.mpq\data" >nul 2>&1
    rmdir /s /q "%appdir%\casctemp" >nul 2>&1
    call :SetFileValue "%settings%" "casc_fastloading" "0"
    call :LogMessage "CASC Fastloading completed"
    echo CASC Fastloading completed.
    call :InstallReimagined
    ) else (
    call :ErrorHandler "Failed to find extracted game files." ConfigurationMenuLoop
  )
  ) else (
  call :ErrorHandler "Installation cancelled." ConfigurationMenuLoop
)
pause
goto ConfigurationMenuLoop

rem D2RMM ONLY SECTION STARTS HERE--------------------------------------

rem _Install/Update for D2RMM Only

:D2RMMInstallUpdate
call :LogMessage "Checking for D2RMM mod installation"
call :Check7zFiles
cls
echo.
echo  %Blue%----- EXTRACTS REIMAGINED FOR D2RMM TO USE -----
echo.
echo %Red%Step 1:%Yellow% You must have Run the D2RMM Application at least once first since extraction.
echo %Red%Step 2:%Yellow% Type "Y" below.  This extracts the mod into the D2RMM Application's Folder.
echo %Red%Step 3:%Yellow% Finally you must run the D2RMM Application and from within there click Install Reimagined.
echo.
echo Mod Zip file detected: %truncated_install_file_name%
echo.
call :GetInput "Would you like to install this version now? (Y/N): " "Y N" && set "install_choice=!result!"
if /i "%install_choice%"=="Y" (
  if exist "%D2RMMappdir%\mods\test" (
    call :LogMessage "Removing old mod files"
    rmdir /s /q "%D2RMMappdir%\mods\test"
  )
  call :D2RMMInstallReimagined
  ) else if /i "%install_choice%"=="N" (
  call :ErrorHandler "Installation skipped." MainMenu
  ) else (
  call :ErrorHandler "Invalid choice. Please enter Y or N." D2RMMInstallUpdate
)

:D2RMMInstallReimagined
if not defined install_file call :ErrorHandler "Error: No installation file found." Check7zFiles
call :LogMessage "Installing %truncated_install_file_name%"
echo Installing %truncated_install_file_name%...
tar -xf "%install_file%" -C "%D2RMMappdir%\mods" --strip-components=2 "mods/Reimagined" >nul 2>&1
if errorlevel 1 call :ErrorHandler "Error: Failed to extract the zip file." D2RMMInstallUpdate
call :LogMessage "Installation completed"
echo Installation completed successfully!
timeout /t 3 >nul
echo Restarting the launcher...
pause
start "" "%~f0"
exit

rem _Configuration Menu

:D2RMMConfigurationMenu
call :LogMessage "Entering configuration menu"
:D2RMMConfigurationMenuLoop
cls
echo.
echo  %Purple%----- MOD TWEAKS ONLY FOR REIMAGINED IN D2RMM -----%Yellow%
echo.
echo To reset these options, re-run %Purple%Install / Update
echo.
echo %Blue%Modification Options:%Yellow%
echo  [1] Remove Aura Sounds (NEW!)
echo  [2] Force Terror Zones (Every Act)
echo  [3] Increase Level Up Stats (2 Skill/8 Attributes)
echo  [4] Letterbox Removal (Removes dim lighting on far edges of screen)
echo  [5] HDR Tooltip Fix
echo  [6] Remove Splash Charm Graphic Effect
echo.
echo  [X] Back to Main Menu
echo.
call :GetInput "What would you like to do: " "1 2 3 4 5 6 X" && set "advoption_choice=!result!"
set "action="
if "%advoption_choice%"=="1" set "action=RemoveAuraSounds"
if "%advoption_choice%"=="2" set "action=ForcedTerrorZones666"
if "%advoption_choice%"=="3" set "action=IncreaseLevelStats"
if "%advoption_choice%"=="4" set "action=LetterboxRemoval"
if "%advoption_choice%"=="5" set "action=HDRTooltipFix"
if "%advoption_choice%"=="6" set "action=SplashCharmGraphic"
if /i "%advoption_choice%"=="X" goto MainMenu
if defined action goto !action!
call :ErrorHandler "Invalid choice. Please try again." D2RMMConfigurationMenuLoop

rem _Configuration Options

:RemoveAuraSounds
call :D2RMMApplyMod "Remove Aura Sounds" "removed_aura_sounds" "%launcher%\utils\mods\Remove Aura Sounds\mods\Reimagined\Reimagined.mpq" "%appdir%\mods\D2RMM\D2RMM.mpq\"

:ForcedTerrorZones666
call :D2RMMApplyMod "Forced Terror Zones666" "forced_terror_zones666" "%launcher%\utils\mods\Force Terror Zones\mods\Reimagined\Reimagined.mpq" "%appdir%\mods\D2RMM\D2RMM.mpq\"

:SplashCharmGraphic
call :D2RMMApplyMod "Splash Charm Graphic Removal" "splash_charm_graphic_removed" "%launcher%\utils\mods\Splash Charm Graphic\mods\Reimagined\Reimagined.mpq" "%appdir%\mods\D2RMM\D2RMM.mpq\"

:IncreaseLevelStats
call :D2RMMApplyMod "Increase Level Stats" "increased_level_stats" "%launcher%\utils\mods\Increase Level Stats\mods\Reimagined\Reimagined.mpq" "%appdir%\mods\D2RMM\D2RMM.mpq\"

:LetterboxRemoval
call :D2RMMApplyMod "Letterbox Removal" "letterbox_removal" "%launcher%\utils\mods\Letterbox\mods\Reimagined\Reimagined.mpq" "%appdir%\mods\D2RMM\D2RMM.mpq\"

:HDRTooltipFix
call :D2RMMApplyMod "HDR Tooltip Fix" "hdr_tooltip_fix" "%launcher%\utils\mods\HDR Tooltip Fix\mods\Reimagined\Reimagined.mpq" "%appdir%\mods\D2RMM\D2RMM.mpq\"

pause
goto D2RMMConfigurationMenuLoop

rem D2RMM SECTION ENDS HERE----------------------------

rem _Backup Menu

:BackupFiles
call :LogMessage "Entering backup menu"
cls
echo.
echo  ----- BACKUP FILES ------
echo.
echo Save Location: "%save_location%"
echo Backup Location: "%backup_location%"
echo.
echo  [1] Create Backup
echo  [2] Open Backup Folder
echo  [3] Restore Backup
echo.
echo  [X] Back to Main Menu
echo.
call :GetInput "What would you like to do? " "1 2 3 X" && set "backup_choice=!result!"
if "%backup_choice%"=="1" call :CreateBackup & goto BackupFiles
if "%backup_choice%"=="2" start "" "%backup_location%" & goto BackupFiles
if "%backup_choice%"=="3" call :RestoreBackup & goto BackupFiles
if /i "%backup_choice%"=="X" goto MainMenu
call :ErrorHandler "Invalid choice." BackupFiles

rem _Create Backup Save

:CreateBackup
call :LogMessage "Creating backup"
where tar >nul 2>&1
if errorlevel 1 call :ErrorHandler "Error: tar is not available." MainMenu
if not exist "%backup_location%" md "%backup_location%" >nul 2>&1
for /f "tokens=*" %%A in ('powershell -Command "Get-Date -Format yyyyMMdd-HHmmss"') do set "current_date=%%A"
set "backup_file_name=%backup_location%\%current_date%.zip"
tar -a -c -f "%backup_file_name%" -C "%d2r_mod_saves%" "ReimaginedThree" >nul 2>&1
if errorlevel 1 call :ErrorHandler "Error: Failed to create backup." BackupFiles
call :CopyFile "%settings%" "%backup_location%"
call :CleanOldBackups
call :LogMessage "Backup completed: %backup_file_name%"
echo Backup completed successfully.
pause
exit /b

rem _Restore Backup Save

:RestoreBackup
call :LogMessage "Entering backup restore menu"
cls
echo.
echo  RESTORE BACKUP -----
echo.
echo Save Location: "%save_location%"
echo Backup Location: "%backup_location%"
echo.
echo Available Backups:
set "backup_count=0"
set "backup_list="
for /f "tokens=*" %%F in ('dir /b /o-d "%backup_location%\*.zip"') do (
  set /a backup_count+=1
  set "backup_list=!backup_list! !backup_count!"
  echo  [!backup_count!] %%F
)
echo.
if %backup_count% equ 0 (
  call :ErrorHandler "No backups found." BackupFiles
)
echo  [X] Back to Backup Menu
echo.
call :GetInput "Select a backup to restore (1-%backup_count%) or X to cancel: " "%backup_list% X" && set "restore_choice=!result!"
if /i "!restore_choice!"=="X" goto BackupFiles
set /a backup_index=!restore_choice!-1
set "selected_backup="
set "counter=0"
for /f "tokens=*" %%F in ('dir /b /o-d "%backup_location%\*.zip"') do (
  if !counter! equ !backup_index! set "selected_backup=%backup_location%\%%F"
  set /a counter+=1
)
if not defined selected_backup call :ErrorHandler "Invalid backup selection." RestoreBackup
cls
color 0C
echo WARNING: This will overwrite your current save files in:
echo %save_location%
echo.
call :GetInput "Proceed with restore? (Y/N): " "Y N" && set "confirm_restore=!result!"
if /i "!confirm_restore!"=="Y" (
  color 07
  call :LogMessage "Restoring backup: !selected_backup!"
  rem _Remove existing Reimagined save folder
  if exist "%save_location%" (
    rmdir /s /q "%save_location%" >nul 2>&1
    if errorlevel 1 call :ErrorHandler "Failed to remove existing save folder." RestoreBackup
  )
  rem _Extract backup to save location
  tar -x -f "!selected_backup!" -C "%d2r_mod_saves%" >nul 2>&1
  if errorlevel 1 call :ErrorHandler "Failed to restore backup." RestoreBackup
  rem _Check if settings.txt exists in backup and restore it
  for %%F in ("!selected_backup!") do (
    if exist "%backup_location%\settings.txt" (
      call :CopyFile "%backup_location%\settings.txt" "%launcher%\settings.txt"
      call :LogMessage "Restored settings file"
    )
  )
  call :LogMessage "Backup restore completed"
  echo Backup restored successfully.
  ) else (
  color 07
  call :ErrorHandler "Restore cancelled." BackupFiles
)
pause
exit /b

rem _Utility Functions

:Check7zFiles
call :LogMessage "Checking for Zip files"
set "file_count=0"
set "install_file="
for %%F in ("%launcher%\*D2R Reimagined *.zip") do (
  set /a file_count+=1
  if !file_count! equ 1 set "install_file=%%~F"
)
if !file_count! equ 0 call :ErrorHandler "No Reimagined zip file found. Move the Nexus zip file into the Beta Launcher folder and try again." MainMenu
if !file_count! gtr 1 call :ErrorHandler "Multiple zip files found." InstallUpdate
for %%I in ("!install_file!") do set "truncated_install_file_name=%%~nI"
set "truncated_install_file_name=%truncated_install_file_name%"
exit /b

:FindOrCreateSaveDir
call :LogMessage "Finding save directory"
set "save_location="
for /f "tokens=*" %%A in ('powershell -Command "Get-ChildItem -Path $env:USERPROFILE -Recurse -Directory -Filter ''Reimagined'' -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notmatch ''\\Backup(\\|$)'' -and (Get-ChildItem -Path $_.FullName -Filter ''*.d2s'' -File).Count -gt 0 } | Sort-Object LastWriteTime -Descending | Select-Object -First 1 -ExpandProperty FullName"') do set "save_location=%%A"
if not defined save_location set "save_location=%USERPROFILE%\Saved Games\Diablo II Resurrected\mods\ReimaginedThree"
if not exist "%save_location%" (
  md "%save_location%" >nul 2>&1
  if errorlevel 1 call :ErrorHandler "Failed to create save directory." MainMenu
)
for %%I in ("%save_location%") do set "d2r_mod_saves=%%~dpI"
if "%d2r_mod_saves:~-1%"=="\" set "d2r_mod_saves=%d2r_mod_saves:~0,-1%"
call :SetFileValue "%settings%" "save_location" "%save_location%"
call :LogMessage "Save directory set to %save_location%"
exit /b

:FindOrCreateBackupDir
call :LogMessage "Finding backup directory"
if not defined backup_location set "backup_location=%d2r_mod_saves%\Reimagined Backups"
if not exist "%backup_location%" (
  md "%backup_location%" >nul 2>&1
  if errorlevel 1 call :ErrorHandler "Failed to create backup directory." MainMenu
)
call :SetFileValue "%settings%" "backup_location" "%backup_location%"
call :LogMessage "Backup directory set to %backup_location%"
exit /b

:VerifyD2RInstall
call :LogMessage "Verifying D2R installation"
if not defined appdir call :ErrorHandler "Diablo II Resurrected not installed." Exit
if not exist "%appdir%\D2R.exe" call :ErrorHandler "D2R.exe not found." Exit
exit /b

:VerifyReimaginedFolder
call :LogMessage "Verifying Reimagined mod folder"
set "mod_checked=1"
if exist "%appdir%\mods\Reimagined\" (
  dir /b "%appdir%\mods\Reimagined" >nul 2>&1
  if not errorlevel 1 set "mod_checked=0"
)
if "%mod_checked%"=="1" call :ErrorHandler "Reimagined mod not installed." InstallUpdate
exit /b

:ApplyMod
call :LogMessage "Configuring %~1"
cls
echo.
echo ----- %~1 -----
echo.
call :GetInput "Proceed? (Y/N): " "Y N" && set "mod_choice=!result!"
if /i "%mod_choice%"=="Y" (
  call :LogMessage "Installing %~1"
  call :CopyFiles "%~3" "%~4"
  call :SetFileValue "%settings%" "%~2" "0"
  echo %~1 installed.
  ) else (
  call :ErrorHandler "Installation cancelled." ConfigurationMenuLoop
)
pause
goto ConfigurationMenuLoop

:D2RMMApplyMod
call :LogMessage "Configuring %~1"
cls
echo.
echo ----- %~1 -----
echo.
call :GetInput "Proceed? (Y/N): " "Y N" && set "mod_choice=!result!"
if /i "%mod_choice%"=="Y" (
  call :LogMessage "Installing %~1"
  call :CopyFiles "%~3" "%~4"
  call :SetFileValue "%settings%" "%~2" "0"
  echo %~1 installed.
  ) else (
  call :ErrorHandler "Installation cancelled." D2RMMConfigurationMenuLoop
)
pause
goto D2RMMConfigurationMenuLoop

:GetInput
set "prompt=%~1"
set "valid=%~2"
set "result="
:GetInputLoop
set /p "result=%prompt%"
for %%V in (%valid%) do if /i "!result!"=="%%V" exit /b 0
call :ErrorHandler "Invalid input. Please enter one of: %valid%." GetInputLoop
exit /b 1

:ErrorHandler
call :LogMessage "ERROR: %~1"
echo %~1
if not "%~2"=="" pause & goto %~2
pause
exit /b

:LogMessage
for /f "tokens=*" %%A in ('powershell -Command "Get-Date -Format 'yyyy-MM-dd HH:mm:ss'"') do set "timestamp=%%A"
for %%F in ("%log_file%") do set "log_size=%%~zF"
if defined log_size if !log_size! gtr 1048576 (
  copy "%log_file%" "%log_file%.bak" >nul
  echo. > "%log_file%"
)
echo [%timestamp%] %~1>>"%log_file%"
if "%debug%"=="1" echo [%timestamp%] %~1
exit /b

:CopyFile
call :LogMessage "Copying file from %~1 to %~2"
copy "%~1" "%~2" >nul 2>&1
if errorlevel 1 call :ErrorHandler "Failed to copy file from '%~1' to '%~2'." Exit
exit /b

:CopyFiles
call :LogMessage "Copying files from %~1 to %~2"
xcopy /e /r /y "%~1" "%~2" >nul 2>&1
if errorlevel 1 call :ErrorHandler "Failed to copy files from '%~1' to '%~2'." Exit
exit /b

:OpenLink
call :LogMessage "Opening link %~1"
start "" "%~1"
exit /b

:CreateCheckSettings
call :LogMessage "Checking settings file"
if not exist "%settings%" (
  (
  echo save_location=
  echo backup_location=
  echo removed_aura_sounds=1
  echo forced_terror_zones=1
  echo splash_charm_graphic_removed=1
  echo increased_level_stats=1
  echo golden_town_portals=1
  echo letterbox_removal=1
  echo casc_fastloading=1
  echo forced_terror_zones666=1
  ) > "%settings%"
  call :LogMessage "Created new settings file"
)
for /f "tokens=1,2 delims==" %%A in ('findstr "=" "%settings%"') do set "%%A=%%B"
exit /b

:SetFileValue
call :LogMessage "Setting %2=%3 in %1"
if not exist "%~1" (
  echo %~2=%~3>"%~1"
  set "%~2=%~3"
  exit /b
)
powershell -NoProfile -Command "if ((Get-Content '%~1') -match '^\s*%~2\s*=') { (Get-Content '%~1') -replace '^\s*%~2\s*=.*', '%~2=%~3' | Set-Content '%~1' } else { Add-Content -Path '%~1' -Value '%~2=%~3' }"
set "%~2=%~3"
exit /b

:CleanOldBackups
for /f "skip=%max_backups% tokens=*" %%F in ('dir /b /o-d "%backup_location%\*.zip"') do del "%backup_location%\%%F"
exit /b

ENDLOCAL